//
//  MPLibraryInformationCell.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/23.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPLibraryInformationCell.h"
#import "UIImageView+WebCache.h"

@interface MPLibraryInformationCell()

@property (nonatomic, strong) UIImageView *albumView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *countLabel;

@end

@implementation MPLibraryInformationCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.albumView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 15, 64, 64)];
        self.albumView.backgroundColor = [UIColor colorWithRed:248/255. green:245/255. blue:240/255. alpha:1];
        self.albumView.layer.cornerRadius = 8;
        self.albumView.layer.masksToBounds = YES;
        [self.contentView addSubview:self.albumView];
        
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(94, 15, width - 100, 16)];
        self.titleLabel.font = [UIFont boldSystemFontOfSize:14];
        self.titleLabel.textColor = [UIColor blackColor];
        [self.contentView addSubview:self.titleLabel];
        
        self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(94, CGRectGetMidY(self.albumView.frame) - 6, width - 100, 12)];
        self.nameLabel.font = [UIFont systemFontOfSize:12];
        self.nameLabel.textColor = [UIColor colorWithRed:1/255. green:145/255. blue:234/255. alpha:1];
        [self.contentView addSubview:self.nameLabel];
        
        UIImageView *listIcon = [[UIImageView alloc] initWithFrame:CGRectMake(94, CGRectGetMaxY(self.albumView.frame)  - 15, 15, 15)];
        listIcon.image = [UIImage imageNamed:@"list_icon_grey"];
        [self.contentView addSubview:listIcon];
        
        self.countLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(listIcon.frame) + 10, CGRectGetMaxY(self.albumView.frame)  - 15, 120, 15)];
        self.countLabel.textColor = [UIColor colorWithRed:153/255. green:153/255. blue:153/255. alpha:1];
        self.countLabel.font = [UIFont systemFontOfSize:10];
        [self.contentView addSubview:self.countLabel];
        
        UIImageView *moreIcon = [[UIImageView alloc] initWithFrame:CGRectMake(width - 15 - 15, CGRectGetMidY(self.countLabel.frame)  - 2, 15, 4)];
        moreIcon.image = [UIImage imageNamed:@"more_icon"];
        [self.contentView addSubview:moreIcon];
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(15, 93, width - 30, 1)];
        line.backgroundColor =[UIColor colorWithRed: 236/255. green:236/255. blue:236/255. alpha:1];
        [self.contentView addSubview:line];
    }
    return self;
}

- (void)setDataDict:(NSDictionary *)dataDict {
    _dataDict = dataDict;
    [self.albumView sd_setImageWithURL:[NSURL URLWithString:[dataDict objectForKey:@"coverImgUrl"]]];
    self.titleLabel.text = [dataDict objectForKey:@"name"];
    self.nameLabel.text = [dataDict objectForKey:@"name"];
    NSDictionary *creatorInfo = [dataDict objectForKey:@"creator"];
    self.nameLabel.text = [creatorInfo objectForKey:@"nickname"];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy";
    NSTimeInterval timeInterval = [[dataDict objectForKey:@"createTime"] floatValue]/1000;
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:timeInterval];
    NSString *dateS = [formatter stringFromDate:date];
    
    NSInteger count = [[dataDict objectForKey:@"trackCount"]integerValue];
    self.countLabel.text = [NSString stringWithFormat:@"%ld Tracks - %@",count, dateS];
}

@end
