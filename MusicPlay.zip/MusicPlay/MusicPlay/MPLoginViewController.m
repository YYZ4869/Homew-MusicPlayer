//
//  MPLoginViewController.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/23.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPLoginViewController.h"
#import "Masonry.h"

@interface MPLoginViewController ()<UITextFieldDelegate>

@property(nonatomic, strong) UITextField *accountTextField;
@property(nonatomic, strong) UITextField *passwordTextField;

@end

@implementation MPLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupView];
}

- (void)setupView {
    UIImageView *logoView = [[UIImageView alloc] init];
    logoView.backgroundColor = [UIColor redColor];
    logoView.image = [UIImage imageNamed:@"app_icon"];
    [self.view addSubview:logoView];
    [logoView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(100, 100));
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.view.mas_top).offset(72);
    }];
    
    UIImageView *accountBG = [[UIImageView alloc] initWithFrame:CGRectZero];
    accountBG.image = [UIImage imageNamed:@"account_bg"];
    accountBG.userInteractionEnabled = YES;
    [self.view addSubview:accountBG];
    [accountBG mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).offset(72);
        make.right.equalTo(self.view).offset(-72);
        make.height.mas_equalTo(44);
        make.top.equalTo(logoView.mas_bottom).offset(53);
    }];
    self.accountTextField = [[UITextField alloc] initWithFrame:CGRectZero];
    self.accountTextField.textColor = [UIColor colorWithRed:28.0/255 green:37/255. blue:42/255. alpha:1];
    self.accountTextField.font = [UIFont systemFontOfSize:19];
    self.accountTextField.delegate = self;
    [accountBG addSubview:self.accountTextField];
    [self.accountTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(44);
        make.left.equalTo(accountBG).offset(22);
        make.right.equalTo(accountBG).offset(-22);
        make.top.equalTo(accountBG);
    }];
    
    UIImageView *passwordBG = [[UIImageView alloc] initWithFrame:CGRectZero];
    passwordBG.image = [UIImage imageNamed:@"account_bg"];
    passwordBG.userInteractionEnabled = YES;
    [self.view addSubview:passwordBG];
    [passwordBG mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).offset(72);
        make.right.equalTo(self.view).offset(-72);
        make.height.mas_equalTo(44);
        make.top.equalTo(accountBG.mas_bottom).offset(15);
    }];
    self.passwordTextField = [[UITextField alloc] initWithFrame:CGRectZero];
    self.passwordTextField.textColor = [UIColor colorWithRed:28.0/255 green:37/255. blue:42/255. alpha:1];
    self.passwordTextField.font = [UIFont systemFontOfSize:19];
    self.passwordTextField.delegate = self;
    [passwordBG addSubview:self.passwordTextField];
    [self.passwordTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(44);
        make.left.equalTo(passwordBG).offset(22);
        make.right.equalTo(passwordBG).offset(-22);
        make.top.equalTo(passwordBG);
    }];
    
    UIButton *forgetButton = [UIButton buttonWithType:UIButtonTypeCustom];
    forgetButton.titleLabel.font = [UIFont systemFontOfSize:14];
    [forgetButton setTitle:@"Forget your password?" forState:UIControlStateNormal];
    [forgetButton setTitleColor:[UIColor colorWithRed:117/255 green:134/255. blue:146/255. alpha:1] forState:UIControlStateNormal];
    [forgetButton addTarget:self action:@selector(forgetPassword:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:forgetButton];
    [forgetButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(passwordBG.mas_bottom).offset(10);
        make.height.mas_equalTo(28);
        make.width.mas_lessThanOrEqualTo(150);
    }];
    
    UIButton *redButton = [UIButton buttonWithType:UIButtonTypeCustom];
    redButton.titleLabel.font = [UIFont systemFontOfSize:14];
    [redButton setTitle:@"Forget your password?" forState:UIControlStateNormal];
    [redButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [redButton addTarget:self action:@selector(red:) forControlEvents:UIControlEventTouchUpInside];
    redButton.backgroundColor = [UIColor redColor];
    redButton.layer.cornerRadius = 22;
    redButton.layer.masksToBounds = YES;
    [self.view addSubview:redButton];
    [redButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(forgetButton.mas_bottom).offset(17);
        make.right.equalTo(self.view).mas_offset(-97);
        make.left.equalTo(self.view).mas_offset(97);
        make.height.mas_equalTo(44);
    }];
    
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectZero];
    footerView.backgroundColor = [UIColor colorWithRed:247/255. green:248/255. blue:250/255. alpha:1];
    [self.view addSubview:footerView];
    [footerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.view);
        make.right.left.equalTo(self.view);
        make.height.mas_equalTo(200);
    }];
    
    UILabel *promptLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    promptLabel.textAlignment = NSTextAlignmentCenter;
    promptLabel.textColor = [UIColor colorWithRed:117/255. green:134/255. blue:146/255. alpha:1];
    promptLabel.font = [UIFont systemFontOfSize:14];
    promptLabel.text = @"Sign with social account";
    [footerView addSubview:promptLabel];
    [promptLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(footerView);
        make.top.equalTo(footerView).offset(25);
        make.height.mas_equalTo(14);
        make.width.mas_lessThanOrEqualTo(200);
    }];
    
    UIButton *faceboodButton = [UIButton buttonWithType:UIButtonTypeCustom];
    faceboodButton.titleLabel.font = [UIFont boldSystemFontOfSize:18];
    [faceboodButton setTitle:@"login with facebook" forState:UIControlStateNormal];
    [faceboodButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [faceboodButton addTarget:self action:@selector(loginWithFacebook:) forControlEvents:UIControlEventTouchUpInside];
    faceboodButton.backgroundColor = [UIColor colorWithRed:38/255. green:46/255. blue:164/255. alpha:1];
    faceboodButton.layer.cornerRadius = 22;
    faceboodButton.layer.masksToBounds = YES;
    [footerView addSubview:faceboodButton];
    [faceboodButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(promptLabel.mas_bottom).offset(17);
        make.right.equalTo(self.view).mas_offset(-97);
        make.left.equalTo(self.view).mas_offset(97);
        make.height.mas_equalTo(44);
    }];
    
    UIButton *twitterButton = [UIButton buttonWithType:UIButtonTypeCustom];
    twitterButton.titleLabel.font = [UIFont boldSystemFontOfSize:18];
    [twitterButton setTitle:@"login with twitter" forState:UIControlStateNormal];
    [twitterButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [twitterButton addTarget:self action:@selector(loginWithTwitter:) forControlEvents:UIControlEventTouchUpInside];
    twitterButton.backgroundColor = [UIColor colorWithRed:15/255. green:123/255. blue:229/255. alpha:1];
    twitterButton.layer.cornerRadius = 22;
    twitterButton.layer.masksToBounds = YES;
    [footerView addSubview:twitterButton];
    [twitterButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(faceboodButton.mas_bottom).offset(17);
        make.right.equalTo(self.view).mas_offset(-58);
        make.left.equalTo(self.view).mas_offset(58);
        make.height.mas_equalTo(44);
    }];
}

- (void)forgetPassword:(UIButton *)sender {
    
}

- (void)red:(UIButton *)sender {
//    if (!self.accountTextField.text.length) {
//        return;
//    }
//    if (!self.passwordTextField.text.length) {
//        return;
//    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"loginSuccess" object:nil];
}

- (void)loginWithFacebook:(UIButton *)sender {
    
}

- (void)loginWithTwitter:(UIButton *)sender {
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    
}

@end
