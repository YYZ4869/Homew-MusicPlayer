//
//  MPRequestManager.h
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/23.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^SuccessBlock)(id object);
typedef void(^failBlock)(NSError *error);
typedef void(^Cache)(id object);
#define uid @"70809997"

NS_ASSUME_NONNULL_BEGIN

@interface MPRequestManager : NSObject

+ (instancetype)sharedInstance;

//get
- (NSNumber *)requestWithUrl:(NSString *)url
                      params:(NSDictionary *)params
                successBlock:(SuccessBlock)success
                 failedBlock:(failBlock)failed;

//post
- (NSNumber *)sendWithUrl:(NSString *)url
                   params:(NSDictionary *)params
             successBlock:(SuccessBlock)success
              failedBlock:(failBlock)failed;

- (void)cancelAllTask;

- (void)cancelTaskWithTaskIdentifier:(NSNumber *)taskIdentifier;

@end

NS_ASSUME_NONNULL_END
