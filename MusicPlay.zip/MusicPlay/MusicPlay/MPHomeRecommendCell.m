//
//  MPHomeRecommendCell.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/23.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPHomeRecommendCell.h"
#import "Masonry.h"
#import "UIImageView+WebCache.h"

@interface MPHomeRecommendCell()

@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *descLabel;

@end

@implementation MPHomeRecommendCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.imageView = [[UIImageView alloc] initWithFrame:CGRectMake(5, 5, frame.size.width - 10, frame.size.width - 10)];
        self.imageView.backgroundColor = [UIColor colorWithRed:248/255. green:245/255. blue:240/255. alpha:1];
        self.imageView.layer.cornerRadius = 8;
        self.imageView.layer.masksToBounds = YES;
        [self.contentView addSubview:self.imageView];
        
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, CGRectGetMaxY(self.imageView.frame) + 10, frame.size.width - 10, 16)];
        self.titleLabel.font = [UIFont boldSystemFontOfSize:14];
        self.titleLabel.textColor = [UIColor colorWithRed:51/255. green:51/255. blue:51/255. alpha:1];
        [self.contentView addSubview:self.titleLabel];
        
        self.descLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, CGRectGetMaxY(self.titleLabel.frame) + 10, frame.size.width - 10, 10)];
        self.descLabel.font = [UIFont systemFontOfSize:10];
        self.descLabel.textColor = [UIColor colorWithRed:1/255. green:145/255. blue:234/255. alpha:1];
        [self.contentView addSubview:self.descLabel];
    }
    return self;
}

- (void)setDataDict:(NSDictionary *)dataDict {
    _dataDict = dataDict;
    NSString *imageUrl = [dataDict objectForKey:@"coverImgUrl"];
    if (imageUrl.length) {
        [self.imageView sd_setImageWithURL:[NSURL URLWithString:imageUrl]];
    }
    NSString *name = [dataDict objectForKey:@"name"];
    if (name.length) {
        self.titleLabel.text = name;
    }
    NSString *desc = [dataDict objectForKey:@"description"];
    if ([desc isKindOfClass:[NSString class]]) {
        self.descLabel.text = desc;
    }
}
/*
"name": "劳动节：致无名英雄，幸福并感激着", //歌单名字
    "id": 4984317152,                //歌单id，获取歌单详情相关
    ...
    "trackCount": 32,        //歌曲数
    "cloudTrackCount": 0,
    "coverImgUrl": "http://p1.music.126.net/-6MF3Ox61TUwcPjZh7Pguw==/109951164932914816.jpg",    //歌单封面
    "coverImgId": 109951164932914820,
    "description": "致无名英雄：\n\n在茫茫的人海中 不知你是哪一个\n在奔腾的浪花里 不知你是哪一朵\n在征服宇宙的大军里 是你默默奉献\n在辉煌事业的长河中 你在永远奔腾\n虽然我不认识你 也不知道你的名字\n但山知道你 江河知道你\n祖国不会忘记你\n\n幸福并感激着！",
    "tags": [
        "华语",
        "流行",
        "感动"
    ],
    ...
    "creator": {
        ...
        "avatarUrl": "http://p1.music.126.net/vercp6mHD9e_kUUKFBBo5A==/109951164508150919.jpg",
        ...
        "userId": 82179192,
        "userType": 200,
        "nickname": "艾琳艾德勒丶",    //歌单创建者
        "signature": "小艾琳 A.K.A Lil Irene\nBrainy is the new sexy.",
        ...
    }
}
*/

@end
