//
//  MPTabBarController.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/22.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPTabBarController.h"
#import "MPNavigationController.h"
#import "MPUserRootViewController.h"
#import "MPHomeRootViewController.h"
#import "MPLibraryRootViewController.h"

@interface MPTabBarController ()

@property (nonatomic, assign) NSInteger selectIndex;

@end

@implementation MPTabBarController

+ (void)initialize {
    
    // 设置为不透明
    [[UITabBar appearance] setTranslucent:NO];
    // 设置背景颜色
    [UITabBar appearance].barTintColor = [UIColor colorWithRed:0.97f green:0.97f blue:0.97f alpha:1.00f];
    
    // 拿到整个导航控制器的外观
    UITabBarItem * item = [UITabBarItem appearance];
    item.titlePositionAdjustment = UIOffsetMake(0, 1.5);
    
    // 普通状态
    NSMutableDictionary * normalAtts = [NSMutableDictionary dictionary];
    normalAtts[NSFontAttributeName] = [UIFont systemFontOfSize:13];
    normalAtts[NSForegroundColorAttributeName] = [UIColor colorWithRed:0.62f green:0.62f blue:0.63f alpha:1.00f];
    [item setTitleTextAttributes:normalAtts forState:UIControlStateNormal];
    
    // 选中状态
    NSMutableDictionary *selectAtts = [NSMutableDictionary dictionary];
    selectAtts[NSFontAttributeName] = [UIFont systemFontOfSize:13];
    selectAtts[NSForegroundColorAttributeName] = [UIColor colorWithRed:0.42f green:0.33f blue:0.27f alpha:1.00f];
    [item setTitleTextAttributes:selectAtts forState:UIControlStateSelected];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addChildViewControllerWithClassname:[MPHomeRootViewController description] imagename:@"tabbar_home_unselected" selectedImagename:@"tabbar_home_selected" title:@"Home"];
    [self addChildViewControllerWithClassname:[MPLibraryRootViewController description] imagename:@"tabbar_library_unselected" selectedImagename:@"tabbar_library_selected" title:@"Library"];
    [self addChildViewControllerWithClassname:[MPUserRootViewController description] imagename:@"tabbar_user_unselected" selectedImagename:@"tabbar_user_selected" title:@"Me"];
}

// 添加子控制器
- (void)addChildViewControllerWithClassname:(NSString *)classname
                                  imagename:(NSString *)imagename
                          selectedImagename:(NSString *)selectedImagename
                                      title:(NSString *)title {
    
    UIViewController *vc = [[NSClassFromString(classname) alloc] init];
    MPNavigationController *nav = [[MPNavigationController alloc] initWithRootViewController:vc];
    nav.tabBarItem.image = [UIImage imageNamed:imagename];
    nav.tabBarItem.selectedImage = [UIImage imageNamed:imagename];
    nav.tabBarItem.title = title;
    [nav.tabBarItem setTitlePositionAdjustment:UIOffsetMake(0, -2)];
    
    [self addChildViewController:nav];
}

- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item {
    
    NSInteger index = [self.tabBar.items indexOfObject:item];
    if (index != self.selectIndex) {
        self.selectIndex = index;
    }
}

@end
