//
//  MPHomeHeaderAlbumView.h
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/23.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MPHomeHeaderAlbumView : UICollectionReusableView

@property (nonatomic, strong) NSMutableArray *dataList;
@property (nonatomic, copy) void(^didSelectedItem)(NSInteger albumId);

@end

NS_ASSUME_NONNULL_END
