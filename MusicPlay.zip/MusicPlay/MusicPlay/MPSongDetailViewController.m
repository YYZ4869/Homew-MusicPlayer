//
//  MPSongDetailViewController.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/24.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPSongDetailViewController.h"
#import "MPSongPlayView.h"
#import "MPRequestManager.h"

@interface MPSongDetailViewController ()

@property (nonatomic, strong) MPSongPlayView *playView;

@property (nonatomic, assign) NSInteger songId;
@end

@implementation MPSongDetailViewController

- (instancetype)initWithSongId:(NSInteger)songId {
    self = [super init];
    if (self) {
        self.songId = songId;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self setupView];
    [self request];
}

- (void)setupView {
    self.playView = [[MPSongPlayView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - 64 - 44)];
    self.playView.hidden = YES;
    [self.view addSubview:self.playView];
    
    UIButton *moreButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
    [moreButton setImage:[UIImage imageNamed:@"more_icon"] forState:UIControlStateNormal];
    
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:moreButton];
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
}

- (void)request {
    NSString *urlString = @"/song/detail";
    __weak typeof(self) weakSelf = self;
    [[MPRequestManager sharedInstance] requestWithUrl:urlString params:@{@"ids": [NSString stringWithFormat:@"%@",@(self.songId)]} successBlock:^(id object) {
        NSLog(@"%@", object);
        NSArray *arr = [object objectForKey:@"songs"];
        if (arr.count) {
            weakSelf.playView.dataDict = arr[0];
            weakSelf.playView.hidden = NO;
        }
        
    } failedBlock:^(NSError *error) {
        
    }];
}
@end
