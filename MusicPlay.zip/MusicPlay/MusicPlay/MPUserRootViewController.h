//
//  MPUserRootViewController.h
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/22.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MPUserRootViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
