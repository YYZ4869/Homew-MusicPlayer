//
//  MPAlbumInfoHeaderView.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/24.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPAlbumInfoHeaderView.h"
#import "UIImageView+WebCache.h"

@interface MPAlbumInfoHeaderView()

@property (nonatomic, strong) UIImageView *albumView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *countLabel;

@end

@implementation MPAlbumInfoHeaderView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:245/255. green:246/255. blue:248/255. alpha:1];
        
        self.albumView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 15, 72, 72)];
        self.albumView.backgroundColor = [UIColor colorWithRed:248/255. green:245/255. blue:240/255. alpha:1];
        self.albumView.layer.cornerRadius = 8;
        self.albumView.layer.masksToBounds = YES;
        [self addSubview:self.albumView];
        
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(94, 15, width - 100, 16)];
        self.titleLabel.font = [UIFont boldSystemFontOfSize:13];
        self.titleLabel.textColor = [UIColor blackColor];
        [self addSubview:self.titleLabel];
        
        self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(102, CGRectGetMidY(self.albumView.frame) - 6, width - 100, 12)];
        self.nameLabel.font = [UIFont systemFontOfSize:12];
        self.nameLabel.textColor = [UIColor colorWithRed:1/255. green:145/255. blue:234/255. alpha:1];
        [self addSubview:self.nameLabel];
        
        UIImageView *listIcon = [[UIImageView alloc] initWithFrame:CGRectMake(102, CGRectGetMaxY(self.albumView.frame)  - 15, 15, 15)];
        listIcon.image = [UIImage imageNamed:@"list_icon_grey"];
        [self addSubview:listIcon];
        
        self.countLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(listIcon.frame) + 10, CGRectGetMaxY(self.albumView.frame)  - 15, 120, 15)];
        self.countLabel.textColor = [UIColor colorWithRed:153/255. green:153/255. blue:153/255. alpha:1];
        self.countLabel.font = [UIFont systemFontOfSize:10];
        [self addSubview:self.countLabel];
        
        UIImageView *moreIcon = [[UIImageView alloc] initWithFrame:CGRectMake(width - 15 - 15, CGRectGetMidY(self.countLabel.frame)  - 2, 15, 4)];
        moreIcon.image = [UIImage imageNamed:@"more_icon"];
        [self addSubview:moreIcon];
    }
    return self;
}

- (void)setDataDict:(NSDictionary *)dataDict {
    _dataDict = dataDict;
    [self.albumView sd_setImageWithURL:[NSURL URLWithString:[dataDict objectForKey:@"imageUrl"]]];
    self.titleLabel.text = [dataDict objectForKey:@"name"];
    self.nameLabel.text = [dataDict objectForKey:@"author"];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy";
    NSTimeInterval timeInterval = [[dataDict objectForKey:@"publishTime"] floatValue]/1000;
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:timeInterval];
    NSString *dateS = [formatter stringFromDate:date];
    
    NSInteger count = [[dataDict objectForKey:@"count"]integerValue];
    self.countLabel.text = [NSString stringWithFormat:@"%ld Tracks - %@",count, dateS];
}

@end
