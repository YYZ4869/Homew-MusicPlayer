//
//  MPLibraryRootViewController.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/22.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPLibraryRootViewController.h"
#import "MPRequestManager.h"
#import "MPLibraryInformationCell.h"
#import "MPAlbumListViewController.h"

@interface MPLibraryRootViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataList;

@end

@implementation MPLibraryRootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.dataList = [NSMutableArray array];
    self.title = @"Library";
    [self setupView];
    [self request];
}

- (void)setupView {
    CGSize size = [UIScreen mainScreen].bounds.size;
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0,size.width, size.height - 64- 44) style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.tableFooterView = [UIView new];
    [self.view addSubview:self.tableView];
}

- (void)request {
    NSString *urlStirng = @"/user/playlist";
    __weak typeof(self) weakSelf = self;
    NSDictionary *params = @{@"uid": uid};
    [[MPRequestManager sharedInstance] requestWithUrl:urlStirng params:params successBlock:^(id object) {
        NSLog(@"object == %@", object);
        NSArray *list = [object objectForKey:@"playlist"];
        if (list.count) {
            [weakSelf.dataList addObjectsFromArray:list];
        }
        [weakSelf.tableView reloadData];
    } failedBlock:^(NSError *error) {
        NSLog(@"object == %@", error);
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MPLibraryInformationCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MPLibraryInformationCell"];
    if (!cell) {
        cell = [[MPLibraryInformationCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MPLibraryInformationCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.dataDict = self.dataList[indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 94;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *dict = self.dataList[indexPath.item];
    NSInteger albumId = [[dict objectForKey:@"id"] integerValue];
    MPAlbumListViewController *vc = [[MPAlbumListViewController alloc] initWithAlbumId:albumId isAlbum:NO];
    [self.navigationController pushViewController:vc animated:YES];
}


@end
