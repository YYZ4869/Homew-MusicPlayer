//
//  MPHomeHeaderAlbumView.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/23.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPHomeHeaderAlbumView.h"
#import "MPHomeNewAlbumCell.h"

@interface MPHomeHeaderAlbumView()<UICollectionViewDelegate, UICollectionViewDataSource>

@property (nonatomic, strong) UICollectionView *collectionView;

@end

@implementation MPHomeHeaderAlbumView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        
        self.dataList = [NSMutableArray array];
        
        UILabel *albmenTitle = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, [UIScreen mainScreen].bounds.size.width, 32)];
        albmenTitle.text = @"New Albums";
        albmenTitle.textColor = [UIColor colorWithRed:51/255. green:51/255. blue:51/255. alpha:1];
        albmenTitle.font = [UIFont boldSystemFontOfSize:15];
        [self addSubview:albmenTitle];
        
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.minimumLineSpacing = 10;
        layout.minimumInteritemSpacing = 10;
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        CGFloat rate = 133/213.;
        CGFloat width = [UIScreen mainScreen].bounds.size.width - 40;
        CGFloat height = width * rate;
        layout.itemSize = CGSizeMake(width, height);
        
        self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 38, [UIScreen mainScreen].bounds.size.width, height) collectionViewLayout:layout];
        self.collectionView.delegate = self;
        self.collectionView.dataSource = self;
        self.collectionView.backgroundColor = [UIColor whiteColor];
        self.collectionView.pagingEnabled = YES;
        [self.collectionView registerClass:[MPHomeNewAlbumCell class] forCellWithReuseIdentifier:@"MPHomeNewAlbumCell"];
        [self addSubview:self.collectionView];
        
        UILabel *recommendTitle = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(self.collectionView.frame), [UIScreen mainScreen].bounds.size.width, 32)];
        recommendTitle.text = @"Recommendations";
        recommendTitle.textColor = [UIColor colorWithRed:51/255. green:51/255. blue:51/255. alpha:1];
        recommendTitle.font = [UIFont boldSystemFontOfSize:15];
        [self addSubview:recommendTitle];
    }
    return self;
}

- (void)setDataList:(NSMutableArray *)dataList {
    _dataList = dataList;
    [self.collectionView reloadData];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.dataList.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    MPHomeNewAlbumCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MPHomeNewAlbumCell" forIndexPath:indexPath];
    cell.dataDict = self.dataList[indexPath.item];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *dict = self.dataList[indexPath.item];
    NSInteger albumId = [[dict objectForKey:@"id"] integerValue];
    if (self.didSelectedItem) {
        self.didSelectedItem(albumId);
    }
}

@end
