//
//  MPUserRootViewController.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/22.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPUserRootViewController.h"
#import "PMUserInformationView.h"
#import "MPRequestManager.h"
#import "UIImageView+WebCache.h"

@interface MPUserRootViewController ()

@property (nonatomic, strong) UIImageView *bgImageView;
@property (nonatomic, strong) PMUserInformationView *infoView;
@property (nonatomic, strong) UIButton *likeButton;
@property (nonatomic, strong) UIButton *messageButton;
@property (nonatomic, strong) UIButton *praiseButton;

@end

@implementation MPUserRootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupView];
    [self request];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.hidden = NO;
}

- (void)setupView {
    
    [self.view addSubview:self.bgImageView];
    [self.view addSubview:self.infoView];
    [self.view addSubview:self.messageButton];
    [self.view addSubview:self.likeButton];
    [self.view addSubview:self.praiseButton];
}

- (void)request {
    NSString *urlString = @"/user/detail";
    __weak typeof(self) weakSelf = self;
    [[MPRequestManager sharedInstance] requestWithUrl:urlString params:@{@"uid": uid} successBlock:^(id object) {
        NSLog(@"%@", object);
        NSDictionary *dataDict = [object objectForKey:@"profile"];
        [weakSelf.bgImageView sd_setImageWithURL:[dataDict objectForKey:@"backgroundUrl"]];
        weakSelf.infoView.dataDict = dataDict;
        
    } failedBlock:^(NSError *error) {
        
    }];
}

- (UIImageView *)bgImageView {
    if (!_bgImageView) {
        _bgImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - 175 - 44)];
        _bgImageView.backgroundColor = [UIColor redColor];
    }
    return _bgImageView;
}

- (PMUserInformationView *)infoView {
    if (!_infoView) {
        _infoView = [[PMUserInformationView alloc] initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height - 175 - 44, [UIScreen mainScreen].bounds.size.width, 155)];
        _infoView.backgroundColor = [UIColor colorWithRed:245/255. green:245/255.0 blue:245/255. alpha:1];
    }
    return _infoView;
}

- (UIButton *)likeButton {
    if (!_likeButton) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        _likeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_likeButton setImage:[UIImage imageNamed:@"like_icon"] forState:UIControlStateNormal];
        _likeButton.backgroundColor = [UIColor colorWithRed:255/255. green:23/255.0 blue:68/255. alpha:1];
        _likeButton.layer.cornerRadius = 15;
        _likeButton.layer.masksToBounds = YES;
        _likeButton.frame = CGRectMake(width/4. - 27, [UIScreen mainScreen].bounds.size.height - 175 - 15 - 44, 54, 30);
    }
    return _likeButton;
}

- (UIButton *)messageButton {
    if (!_messageButton) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        _messageButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_messageButton setImage:[UIImage imageNamed:@"message_icon"] forState:UIControlStateNormal];
        _messageButton.backgroundColor = [UIColor colorWithRed:76/255. green:185/255.0 blue:6/255. alpha:1];//76,185,6
        _messageButton.layer.cornerRadius = 15;
        _messageButton.layer.masksToBounds = YES;
        _messageButton.frame = CGRectMake(width/2. - 27, [UIScreen mainScreen].bounds.size.height - 175 - 15 - 44, 54, 30);
    }
    return _messageButton;
}

- (UIButton *)praiseButton {
    if (!_praiseButton) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        _praiseButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_praiseButton setImage:[UIImage imageNamed:@"Ok_icon"] forState:UIControlStateNormal];
        _praiseButton.backgroundColor = [UIColor colorWithRed:1/255. green:145/255.0 blue:234/255. alpha:1];
        _praiseButton.layer.cornerRadius = 15;
        _praiseButton.layer.masksToBounds = YES;
        _praiseButton.frame = CGRectMake(width/4. * 3 - 27, [UIScreen mainScreen].bounds.size.height - 175 - 15 - 44, 54, 30);
    }
    return _praiseButton;
}

@end
