//
//  MPAlbumListViewCell.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/24.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPAlbumListViewCell.h"
#import "Masonry.h"

@interface MPAlbumListViewCell()

@property (nonatomic, strong) UILabel *indexLabel;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *timeLabel;

@end

@implementation MPAlbumListViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.indexLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, 10, 20, 16)];
        self.indexLabel.textAlignment = NSTextAlignmentCenter;
        self.indexLabel.text = @"1";
        self.indexLabel.font = [UIFont systemFontOfSize:14];
        self.indexLabel.textColor = [UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1];
        [self.contentView addSubview:self.indexLabel];
        
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(34, 10, 200, 16)];
        self.titleLabel.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1];
        self.titleLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:self.titleLabel];
        
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        self.timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(width - 12 - 100, 10, 100, 16)];
        self.timeLabel.textAlignment = NSTextAlignmentRight;
        self.timeLabel.text = @"04:20";
        self.timeLabel.font = [UIFont systemFontOfSize:14];
        self.timeLabel.textColor = [UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1];
        [self.contentView addSubview:self.timeLabel];
        
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(12, 35, width - 20, 1)];
        line.backgroundColor = [UIColor colorWithRed:236/255.0 green:236/255.0 blue:236/255.0 alpha:1];
    }
    return self;
}

- (void)setDataDict:(NSDictionary *)dataDict {
    _dataDict = dataDict;
    self.titleLabel.text = [dataDict objectForKey:@"name"];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"mm:ss";
    NSTimeInterval timeInterval = [[dataDict objectForKey:@"dt"] floatValue]/1000;
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:timeInterval];
    NSString *dateS = [formatter stringFromDate:date];
    self.timeLabel.text = dateS;
}

/*
 {
     a = "<null>";
     al =             {
         alia =                 (
             "In The Mood For Love"
         );
         id = 89749256;
         name = "\U82b1\U6837\U5e74\U534e";
         pic = 109951165007693710;
         picUrl = "https://p2.music.126.net/BTgQ35IYOYLVvvVed2a5mw==/109951165007693707.jpg";
         "pic_str" = 109951165007693707;
     };
     alia =             (
         "In The Mood For Love"
     );
     ar =             (
                         {
             id = 4292;
             name = "\U674e\U8363\U6d69";
         }
     );
     cd = 01;
     cf = "";
     cp = 1416577;
     crbt = "<null>";
     djId = 0;
     dt = 311857;
     fee = 8;
     ftype = 0;
     h =             {
         br = 320000;
         fid = 0;
         size = 12477165;
         vd = "-47436";
     };
     id = 1449782659;
     l =             {
         br = 128000;
         fid = 0;
         size = 4990893;
         vd = "-43097";
     };
     m =             {
         br = 192000;
         fid = 0;
         size = 7486317;
         vd = "-44814";
     };
     mst = 9;
     mv = 0;
     name = "\U82b1\U6837\U5e74\U534e";
     no = 1;
     noCopyrightRcmd = "<null>";
     pop = 100;
     privilege =             {
         cp = 1;
         cs = 0;
         dl = 0;
         downloadMaxbr = 999000;
         fee = 8;
         fl = 128000;
         flag = 68;
         id = 1449782659;
         maxbr = 999000;
         payed = 0;
         pl = 128000;
         playMaxbr = 999000;
         preSell = 0;
         sp = 7;
         st = 0;
         subp = 1;
         toast = 0;
     };
     pst = 0;
     rt = "";
     rtUrl = "<null>";
     rtUrls =             (
     );
     rtype = 0;
     rurl = "<null>";
     st = 1;
     t = 0;
     v = 3;
 }
 */

@end
