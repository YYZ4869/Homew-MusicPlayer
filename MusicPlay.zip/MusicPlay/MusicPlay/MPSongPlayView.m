//
//  MPSongPlayView.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/24.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPSongPlayView.h"
#import "UIImageView+WebCache.h"
@interface MPSongPlayView()

@property (nonatomic, strong) UIImageView *coverImageView;      //封面
@property (nonatomic, strong) UIButton *orderButton;            //顺序
@property (nonatomic, strong) UIButton *preButton;              //上一首
@property (nonatomic, strong) UIButton *nextButton;             //下一首
@property (nonatomic, strong) UIButton *playButton;             //播放
@property (nonatomic, strong) UIButton *circleButton;           //循环
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *currentTimeLabel;
@property (nonatomic, strong) UILabel *totalTimeLabel;
@property (nonatomic, strong) UIProgressView *progressView;

@end

@implementation MPSongPlayView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        CGFloat height = frame.size.height;
        
        self.coverImageView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 15, width - 30, width - 30)];
        self.coverImageView.backgroundColor = [UIColor colorWithRed:245/255. green:246/255. blue:248/255. alpha:1];
        [self addSubview:self.coverImageView];
        
        self.currentTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, height - 18 - 10, 40, 10)];
        self.currentTimeLabel.textColor = [UIColor colorWithRed:153/255. green:153/255. blue:153/255. alpha:1];
        self.currentTimeLabel.textAlignment = NSTextAlignmentCenter;
        self.currentTimeLabel.font = [UIFont systemFontOfSize:10];
        self.currentTimeLabel.text = @"0:00";
        [self addSubview:self.currentTimeLabel];
        
        self.totalTimeLabel = [[UILabel alloc] initWithFrame:CGRectMake(width - 15 - 40, height - 18 - 10, 40, 10)];
        self.totalTimeLabel.textColor = [UIColor colorWithRed:153/255. green:153/255. blue:153/255. alpha:1];
        self.totalTimeLabel.textAlignment = NSTextAlignmentCenter;
        self.totalTimeLabel.font = [UIFont systemFontOfSize:10];
        self.totalTimeLabel.text = @"9:99";
        [self addSubview:self.totalTimeLabel];
        
        self.progressView = [[UIProgressView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(self.currentTimeLabel.frame) + 5, CGRectGetMidY(self.currentTimeLabel.frame) - 1, CGRectGetMinX(self.totalTimeLabel.frame) - 5 - CGRectGetMaxX(self.currentTimeLabel.frame), 1)];
        self.progressView.trackTintColor = [UIColor colorWithRed:155/255. green:155/255. blue:155/255. alpha:1];
        self.progressView.tintColor = [UIColor colorWithRed:1/255. green:145/255.0 blue:234/255. alpha:1];
        self.progressView.progress = 0.5;
        [self addSubview:self.progressView];
        
        self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(width/2. - 100, CGRectGetMidY(self.totalTimeLabel.frame) - 40, 200, 12)];
        self.nameLabel.textColor = [UIColor colorWithRed:153/255. green:153/255. blue:153/255. alpha:1];
        self.nameLabel.textAlignment = NSTextAlignmentCenter;
        self.nameLabel.font = [UIFont boldSystemFontOfSize:12];
        self.nameLabel.text = @"周杰伦";
        [self addSubview:self.nameLabel];
        
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(width/2. - 100, CGRectGetMinY(self.nameLabel.frame) - 15 - 20, 200, 20)];
        self.titleLabel.textColor = [UIColor colorWithRed:53/255. green:53/255. blue:53/255. alpha:1];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.font = [UIFont boldSystemFontOfSize:20];
        self.titleLabel.text = @"双节棍";
        [self addSubview:self.titleLabel];
        
        self.playButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.playButton setImage:[UIImage imageNamed:@"play_blue"] forState:UIControlStateNormal];
        self.playButton.frame = CGRectMake(width/2.0 - 16, CGRectGetMinY(self.titleLabel.frame) - 15 - 32, 32, 32);
        [self addSubview:self.playButton];
        
        self.orderButton = [UIButton buttonWithType:UIButtonTypeCustom];[UIButton buttonWithType:UIButtonTypeCustom];
        [self.orderButton setImage:[UIImage imageNamed:@"shaffle_icon"] forState:UIControlStateNormal];
        self.orderButton.frame = CGRectMake(15, CGRectGetMinY(self.titleLabel.frame) - 15 - 32, 32, 32);
        [self addSubview:self.orderButton];
        
        self.circleButton = [UIButton buttonWithType:UIButtonTypeCustom];[UIButton buttonWithType:UIButtonTypeCustom];
        [self.circleButton setImage:[UIImage imageNamed:@"repeat_icon"] forState:UIControlStateNormal];
        self.circleButton.frame = CGRectMake(width - 16 - 32, CGRectGetMinY(self.titleLabel.frame) - 15 - 32, 32, 32);
        [self addSubview:self.circleButton];
        
        self.preButton = [UIButton buttonWithType:UIButtonTypeCustom];[UIButton buttonWithType:UIButtonTypeCustom];
        [self.preButton setImage:[UIImage imageNamed:@"pre_icon"] forState:UIControlStateNormal];
        self.preButton.frame = CGRectMake(width/4.0 - 16, CGRectGetMinY(self.titleLabel.frame) - 15 - 32, 32, 32);
        [self addSubview:self.preButton];
        
        self.nextButton = [UIButton buttonWithType:UIButtonTypeCustom];[UIButton buttonWithType:UIButtonTypeCustom];
        [self.nextButton setImage:[UIImage imageNamed:@"next_icon"] forState:UIControlStateNormal];
        self.nextButton.frame = CGRectMake(width/4.0 * 3 - 16, CGRectGetMinY(self.titleLabel.frame) - 15 - 32, 32, 32);
        [self addSubview:self.nextButton];
        
    }
    return self;
}

- (void)setDataDict:(NSDictionary *)dataDict {
    _dataDict = dataDict;
    
    NSDictionary *al = [dataDict objectForKey:@"al"];
    [self.coverImageView sd_setImageWithURL:[NSURL URLWithString:[al objectForKey:@"picUrl"]]];
    
    self.titleLabel.text = [dataDict objectForKey:@"name"];
    self.currentTimeLabel.text = @"0:00";
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"mm:ss";
    NSTimeInterval timeInterval = [[dataDict objectForKey:@"dt"] floatValue]/1000;
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:timeInterval];
    NSString *dateS = [formatter stringFromDate:date];
    self.totalTimeLabel.text = dateS;
    
    self.progressView.progress = 0.0;
    
    NSArray *artist = [dataDict objectForKey:@"ar"];
    if (artist.count) {
        NSDictionary *dict = artist[0];
        self.nameLabel.text = [dict objectForKey:@"name"];
    }
}


@end
