//
//  MPHomeNewAlbumCell.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/23.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPHomeNewAlbumCell.h"
#import "Masonry.h"
#import "UIImageView+WebCache.h"

@interface MPHomeNewAlbumCell()

@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *countLabel;

@end

@implementation MPHomeNewAlbumCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.imageView = [[UIImageView alloc] initWithFrame:self.bounds];
        self.imageView.backgroundColor = [UIColor colorWithRed:248/255. green:245/255. blue:240/255. alpha:1];
        self.imageView.layer.cornerRadius = 8;
        self.imageView.layer.masksToBounds = YES;
        [self.contentView addSubview:self.imageView];
        
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(self.imageView.frame) - 54, frame.size.width - 10, 16)];
        self.titleLabel.font = [UIFont boldSystemFontOfSize:14];
        self.titleLabel.textColor = [UIColor whiteColor];
        [self.contentView addSubview:self.titleLabel];
        
        UIImageView *listIcon = [[UIImageView alloc] initWithFrame:CGRectMake(16, CGRectGetMaxY(self.titleLabel.frame) + 8, 15, 15)];
        listIcon.image = [UIImage imageNamed:@"list_icon"];
        [self.contentView addSubview:listIcon];
        
        self.countLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        self.countLabel.textColor = [UIColor whiteColor];
        self.countLabel.font = [UIFont systemFontOfSize:10];
        [self.contentView addSubview:self.countLabel];
        [self.countLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(listIcon.mas_right).offset(10);
            make.centerY.equalTo(listIcon);
            make.height.mas_equalTo(15);
            make.width.mas_equalTo(200);
        }];
        
        UIButton *playButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [playButton setImage:[UIImage imageNamed:@"home_play"] forState:UIControlStateNormal];
        [playButton addTarget:self action:@selector(play:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:playButton];
        [playButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(32, 32));
            make.centerY.equalTo(listIcon);
            make.right.equalTo(self.contentView).offset(-16);
        }];
    }
    return self;
}

- (void)setDataDict:(NSDictionary *)dataDict {
    _dataDict = dataDict;
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:[dataDict objectForKey:@"picUrl"]]];
    self.titleLabel.text = [dataDict objectForKey:@"name"];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy";
    NSTimeInterval timeInterval = [[dataDict objectForKey:@"publishTime"] floatValue]/1000;
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:timeInterval];
    NSString *dateS = [formatter stringFromDate:date];
    
    NSInteger count = [[dataDict objectForKey:@"size"]integerValue];
    self.countLabel.text = [NSString stringWithFormat:@"%ld Tracks - %@",count, dateS];
}

- (void)play:(UIButton *)sender {
    
}

@end

