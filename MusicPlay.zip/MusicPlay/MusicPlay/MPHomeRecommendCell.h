//
//  MPHomeRecommendCell.h
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/23.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MPHomeRecommendCell : UICollectionViewCell

@property (nonatomic, strong) NSDictionary *dataDict;

@end

NS_ASSUME_NONNULL_END
