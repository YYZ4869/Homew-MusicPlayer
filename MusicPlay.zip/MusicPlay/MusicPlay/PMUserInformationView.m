//
//  PMUserInformationView.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/24.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "PMUserInformationView.h"

@interface PMUserInformationView()

@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *contryLabel;
@property (nonatomic, strong) UILabel *followerCountLabel;
@property (nonatomic, strong) UILabel *postCountLabel;
@property (nonatomic, strong) UILabel *followCountLabel;

@end

@implementation PMUserInformationView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        
        self.nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, 40, width - 24, 15)];
        self.nameLabel.font = [UIFont boldSystemFontOfSize:15];
        self.nameLabel.textColor = [UIColor colorWithRed:51/255. green:51/255. blue:51/255. alpha:1];
        self.nameLabel.textAlignment = NSTextAlignmentCenter;
        self.nameLabel.text = @"杨过";
        [self addSubview:self.nameLabel];
        
        self.contryLabel = [[UILabel alloc] initWithFrame:CGRectMake(12, CGRectGetMaxY(self.nameLabel.frame) + 10, width - 24, 15)];
        self.contryLabel.font = [UIFont systemFontOfSize:12];
        self.contryLabel.textColor = [UIColor colorWithRed:151/255. green:151/255. blue:151/255. alpha:1];
        self.contryLabel.textAlignment = NSTextAlignmentCenter;
        self.contryLabel.text = @"China";
        [self addSubview:self.contryLabel];
        
        CGFloat padding = (width - 300)/3.;
        self.followerCountLabel = [[UILabel alloc] initWithFrame:CGRectMake(padding/2., CGRectGetMaxY(self.contryLabel.frame) + 30, 100, 16)];
        self.followerCountLabel.font = [UIFont systemFontOfSize:16];
        self.followerCountLabel.text = @"5674";
        self.followerCountLabel.textColor = [UIColor colorWithRed:51/255. green:51/255. blue:51/255. alpha:1];
        self.followerCountLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.followerCountLabel];
        
        UILabel *followerLabel = [[UILabel alloc] initWithFrame:CGRectMake(padding/2., CGRectGetMaxY(self.followerCountLabel.frame) + 6, 100, 10)];
        followerLabel.font = [UIFont systemFontOfSize:10];
        followerLabel.textColor = [UIColor colorWithRed:151/255. green:151/255. blue:151/255. alpha:1];
        followerLabel.textAlignment = NSTextAlignmentCenter;
        followerLabel.text = @"Followers";
        [self addSubview:followerLabel];
        
        self.postCountLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMidX(self.frame) - 50, CGRectGetMaxY(self.contryLabel.frame) + 30, 100, 16)];
        self.postCountLabel.font = [UIFont systemFontOfSize:16];
        self.postCountLabel.text = @"5674";
        self.postCountLabel.textColor = [UIColor colorWithRed:51/255. green:51/255. blue:51/255. alpha:1];
        self.postCountLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.postCountLabel];
        
        UILabel *postLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMidX(self.frame) - 50, CGRectGetMaxY(self.postCountLabel.frame) + 6, 100, 10)];
        postLabel.font = [UIFont systemFontOfSize:10];
        postLabel.textColor = [UIColor colorWithRed:151/255. green:151/255. blue:151/255. alpha:1];
        postLabel.textAlignment = NSTextAlignmentCenter;
        postLabel.text = @"Posts";
        [self addSubview:postLabel];
        
        self.followCountLabel = [[UILabel alloc] initWithFrame:CGRectMake(width - padding/2.0 - 100, CGRectGetMaxY(self.contryLabel.frame) + 30, 100, 16)];
        self.followCountLabel.text = @"5674";
        self.followCountLabel.font = [UIFont systemFontOfSize:16];
        self.followCountLabel.textColor = [UIColor colorWithRed:51/255. green:51/255. blue:51/255. alpha:1];
        self.followCountLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.followCountLabel];
        
        UILabel *followLabel = [[UILabel alloc] initWithFrame:CGRectMake(width - padding/2.0 - 100, CGRectGetMaxY(self.followerCountLabel.frame) + 6, 100, 10)];
        followLabel.font = [UIFont systemFontOfSize:10];
        followLabel.textColor = [UIColor colorWithRed:151/255. green:151/255. blue:151/255. alpha:1];
        followLabel.textAlignment = NSTextAlignmentCenter;
        followLabel.text = @"Following";
        [self addSubview:followLabel];
    }
    return self;
}

- (void)setDataDict:(NSDictionary *)dataDict {
    _dataDict = dataDict;
    self.nameLabel.text = [dataDict objectForKey:@"nickname"];
    self.contryLabel.text = [dataDict objectForKey:@"signature"];
    
    self.followerCountLabel.text = [NSString stringWithFormat:@"%@", @([[dataDict objectForKey:@"followMe"] integerValue])];
    self.followCountLabel.text = [NSString stringWithFormat:@"%@", @([[dataDict objectForKey:@"follows"] integerValue])];
    self.postCountLabel.text = [NSString stringWithFormat:@"%@", @([[dataDict objectForKey:@"eventCount"] integerValue])];
}
/*
 {
     adValid = 0;
     bindings =     (
                 {
             bindingTime = 1573699594313;
             expired = 0;
             expiresIn = 2147483647;
             id = 6993042974;
             refreshTime = 1573699594;
             tokenJsonStr = "<null>";
             type = 1;
             url = "";
             userId = 70809997;
         },
                 {
             bindingTime = 1464792283523;
             expired = 0;
             expiresIn = 2688596;
             id = 2863983126;
             refreshTime = 1590250204;
             tokenJsonStr = "<null>";
             type = 2;
             url = "http://weibo.com/u/3778998577";
             userId = 70809997;
         },
                 {
             bindingTime = 1449319452556;
             expired = 1;
             expiresIn = 2592137;
             id = 51781573;
             refreshTime = 1499252262;
             tokenJsonStr = "<null>";
             type = 4;
             url = "http://www.renren.com/579270583";
             userId = 70809997;
         },
                 {
             bindingTime = 1546764944509;
             expired = 1;
             expiresIn = 7776000;
             id = 6770017105;
             refreshTime = 1546765099;
             tokenJsonStr = "<null>";
             type = 5;
             url = "";
             userId = 70809997;
         },
                 {
             bindingTime = 1546764808399;
             expired = 1;
             expiresIn = 7200;
             id = 6769979310;
             refreshTime = 1546764808;
             tokenJsonStr = "<null>";
             type = 10;
             url = "";
             userId = 70809997;
         }
     );
     code = 200;
     createDays = 1828;
     createTime = 1432394336416;
     level = 8;
     listenSongs = 4803;
     mobileSign = 0;
     pcSign = 0;
     peopleCanSeeMyPlayRecord = 1;
     profile =     {
         accountStatus = 0;
         allSubscribedCount = 0;
         artistIdentity =         (
         );
         authStatus = 0;
         authority = 0;
         avatarImgId = 1378787596030317;
         avatarImgIdStr = 1378787596030317;
         avatarUrl = "http://p1.music.126.net/yaeOgaQTXh3rkLQ3A_N-RA==/1378787596030317.jpg";
         backgroundImgId = 18580646999742796;
         backgroundImgIdStr = 18580646999742796;
         backgroundUrl = "http://p1.music.126.net/yrfbC1LP8-S-PBsCKIplBQ==/18580646999742796.jpg";
         birthday = 978698768018;
         blacklist = 0;
         cCount = 0;
         city = 510100;
         createTime = 1432394336416;
         defaultAvatar = 0;
         description = "";
         detailDescription = "";
         djStatus = 0;
         eventCount = 7;
         expertTags = "<null>";
         experts =         {
         };
         followMe = 0;
         followTime = "<null>";
         followed = 0;
         followeds = 6;
         follows = 164;
         gender = 1;
         mutual = 0;
         newFollows = 164;
         nickname = "Kisum_-";
         playlistBeSubscribedCount = 0;
         playlistCount = 10;
         province = 510000;
         remarkName = "<null>";
         sCount = 0;
         sDJPCount = 0;
         signature = "\U97e9\U996d\U4e00\U679a";
         userId = 70809997;
         userType = 0;
         vipType = 10;
     };
     userPoint =     {
         balance = 2066;
         blockBalance = 0;
         status = 1;
         updateTime = 1590310728292;
         userId = 70809997;
         version = 10;
     };
 }
 */

@end
