//
//  MPSongDetailViewController.h
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/24.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MPSongDetailViewController : UIViewController

- (instancetype)initWithSongId:(NSInteger)songId;
@end

NS_ASSUME_NONNULL_END
