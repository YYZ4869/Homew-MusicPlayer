//
//  MPRequestManager.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/23.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPRequestManager.h"
#import "AFNetworking.h"

#define baseURL @"http://47.99.165.194"

typedef NS_ENUM(NSUInteger, MPNetworkRequestType) {
    MPNetworkRequestTypeGet = 0,
    MPNetworkRequestTypePost,
};

@interface MPRequestManager()

@property (strong, nonatomic) AFHTTPSessionManager *sessionManager;
@property (strong, nonatomic) NSMutableDictionary<NSNumber *, NSURLSessionTask *> *dispathTable;

@property (assign, nonatomic) CGFloat totalTaskCount;
@property (assign, nonatomic) CGFloat errorTaskCount;

@end

@implementation MPRequestManager

static dispatch_semaphore_t lock;

+ (instancetype)sharedInstance {
    
    static MPRequestManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        lock = dispatch_semaphore_create(1);
        manager = [[self alloc] init];
    });
    return manager;
}

- (instancetype)init {
    if (self = [super init]) {
        
        self.dispathTable = [NSMutableDictionary dictionary];
        self.totalTaskCount = self.errorTaskCount = 0;
        
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        self.sessionManager = [[AFHTTPSessionManager alloc] initWithBaseURL:[NSURL URLWithString:baseURL] sessionConfiguration:config];
        self.sessionManager.responseSerializer = [AFJSONResponseSerializer serializer];
        
        self.sessionManager.requestSerializer.timeoutInterval = 100.f;
        self.sessionManager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
        _sessionManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/html", @"text/json", @"text/plain", @"text/javascript", @"text/xml", @"image/*", nil];
    }
    return self;
}

/** 取消所有task*/

- (void)cancelAllTask {
    
    for (NSURLSessionTask *task in self.dispathTable.allValues) {
        [task cancel];
    }
    dispatch_semaphore_wait(lock, DISPATCH_TIME_FOREVER);
    [self.dispathTable removeAllObjects];
    dispatch_semaphore_signal(lock);
}

/** 取消指定的task*/

- (void)cancelTaskWithTaskIdentifier:(NSNumber *)taskIdentifier {
    
    [self.dispathTable[taskIdentifier] cancel];
    
    dispatch_semaphore_wait(lock, DISPATCH_TIME_FOREVER);
    [self.dispathTable removeObjectForKey:taskIdentifier];
    dispatch_semaphore_signal(lock);
}

/** task设定*/

- (NSNumber *)dispatchTask:(NSURLSessionDataTask *)task {
    
    if (task == nil) { return @-1; }
    
    dispatch_semaphore_wait(lock, DISPATCH_TIME_FOREVER);
    self.totalTaskCount += 1;
    [self.dispathTable setObject:task forKey:@(task.taskIdentifier)];
    dispatch_semaphore_signal(lock);
    [task resume];
    return @(task.taskIdentifier);
}

/**
 *  网络接口
 *
 *  @param url     url地址
 *  @param requestType     网络请求类型
 *  @param params     请求字段
 */
- (NSURLSessionDataTask *)requestWithUrlPath:(NSString *)url
                                 requestType:(MPNetworkRequestType)requestType
                                      params:(NSDictionary *)params
                                  CacheBlock:(Cache)cache
                                successBlock:(SuccessBlock)success
                                 failedBlock:(failBlock)failed {
    NSLog(@"\n-----------------Send File Request Begin-----------------------\n\n%@\n%@ \n-----------------Send File Request End-----------------------\n\n", url, params);
    url = [NSString stringWithFormat:@"%@%@",baseURL,url];
    //读取缓存
    NSURLSessionDataTask *task;
    __block NSString *taskIdentifier = @"-1";
    if (requestType == MPNetworkRequestTypeGet) {
        
        task = [self.sessionManager GET:url parameters:params
                               progress:nil
                                success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                                    NSLog(@"\n-----------------Send File Response(Success) Begin-----------------------\n\n%@\n%@\n-----------------Send File Response(Success) End-----------------------\n\n", url, responseObject);
                                    success(responseObject);
                                    [self removeKey:@(taskIdentifier.integerValue)];
                                    
                                    
                                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                                    
                                    NSLog(@"\n-----------------Send File Response(Failure) Begin-----------------------\n\n\%@\n%@\n-----------------Send File Response(Failure) End-----------------------\n\n", url, error);
                                    
                                    failed(error);
                                    
                                    [self removeKey:@(taskIdentifier.integerValue)];
                                }];
        
        
    } else if (requestType == MPNetworkRequestTypePost) {
        
        task = [self.sessionManager POST:url parameters:params
                                progress:nil
                                 success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                                     
                                     NSLog(@"\n-----------------Send File Response(Success) Begin-----------------------\n\n%@\n%@\n-----------------Send File Response(Success) End-----------------------\n\n", url, responseObject);
                                     success(responseObject);
                                     
                                     [self removeKey:@(taskIdentifier.integerValue)];
                                     
                                 } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                                     
                                     NSLog(@"\n-----------------Send File Response(Failure) Begin-----------------------\n\n\%@\n%@\n-----------------Send File Response(Failure) End-----------------------\n\n", url, error);
                                     failed(error);
                                     [self removeKey:@(taskIdentifier.integerValue)];
                                     
                                 }];
        
    }
    taskIdentifier = @(task.taskIdentifier).stringValue;
    return task;
    
}

- (NSNumber *)requestWithUrl:(NSString *)url
                      params:(NSDictionary *)params
                successBlock:(SuccessBlock)success
                 failedBlock:(failBlock)failed
{
    return [self dispatchTask:[self requestWithUrlPath:url requestType:MPNetworkRequestTypeGet params:params CacheBlock:nil successBlock:success failedBlock:failed]];
}

- (NSNumber *)sendWithUrl:(NSString *)url params:(NSDictionary *)params successBlock:(SuccessBlock)success failedBlock:(failBlock)failed
{
    return [self dispatchTask:[self requestWithUrlPath:url requestType:MPNetworkRequestTypePost params:params CacheBlock:nil successBlock:success failedBlock:failed]];
}

- (void)removeKey:(NSNumber *)taskIdentifier
{
    dispatch_semaphore_wait(lock, DISPATCH_TIME_FOREVER);
    [self.dispathTable removeObjectForKey:taskIdentifier];
    dispatch_semaphore_signal(lock);
}

@end

#pragma mark - NSDictionary,NSArray的分类
/*
 ************************************************************************************
 *新建NSDictionary与NSArray的分类, 控制台打印json数据中的中文
 ************************************************************************************
 */

#ifdef DEBUG
@implementation NSArray (PP)

- (NSString *)descriptionWithLocale:(id)locale
{
    NSMutableString *strM = [NSMutableString stringWithString:@"(\n"];
    
    [self enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        [strM appendFormat:@"\t%@,\n", obj];
    }];
    
    [strM appendString:@")"];
    
    return strM;
}

@end

@implementation NSDictionary (PP)

- (NSString *)descriptionWithLocale:(id)locale
{
    NSMutableString *strM = [NSMutableString stringWithString:@"{\n"];
    
    [self enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
        [strM appendFormat:@"\t%@ = %@;\n", key, obj];
    }];
    
    [strM appendString:@"}\n"];
    
    return strM;
}
@end
#endif
