//
//  MPAlbumListViewController.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/24.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPAlbumListViewController.h"
#import "MPRequestManager.h"
#import "MPAlbumListViewCell.h"
#import "MPAlbumInfoHeaderView.h"
#import "MPSongDetailViewController.h"

@interface MPAlbumListViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataList;
@property (nonatomic, assign) NSInteger albumId;
@property (nonatomic, assign) BOOL isAlbum;
@property (nonatomic, strong) MPAlbumInfoHeaderView *headerView;

@end

@implementation MPAlbumListViewController

- (instancetype)initWithAlbumId:(NSInteger)albumId isAlbum:(BOOL)isAlbum{
    self = [super init];
    if (self) {
        self.isAlbum = isAlbum;
        self.albumId = albumId;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataList = [NSMutableArray array];
    // Do any additional setup after loading the view.
    [self setupView];
    [self request];
}

- (void)setupView {
    CGSize size = [UIScreen mainScreen].bounds.size;
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0,size.width, size.height - 64 - 44) style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.tableFooterView = [UIView new];
    [self.view addSubview:self.tableView];
}

- (void)request {
    
    NSString *urlStirng = self.isAlbum ? @"/album" : @"/playlist/detail";
    __weak typeof(self) weakSelf = self;
    NSDictionary *params = @{@"id": @(self.albumId)};
    [[MPRequestManager sharedInstance] requestWithUrl:urlStirng params:params successBlock:^(id object) {
        NSLog(@"object == %@", object);
        if (weakSelf.isAlbum) {
            NSDictionary *dataDict = [object objectForKey:@"album"];
            NSDictionary *artist = [dataDict objectForKey:@"artist"];
            NSDictionary *dict = @{
                @"author": [artist objectForKey:@"name"],
                @"name": [dataDict objectForKey:@"name"],
                @"imageUrl": [dataDict objectForKey:@"picUrl"],
                @"count": [dataDict objectForKey:@"size"],
                @"publishTime": @([[dataDict objectForKey:@"publishTime"] integerValue])
            };
            weakSelf.headerView.dataDict = dict;
            NSArray *songs = [object objectForKey:@"songs"];
            if (songs.count) {
                [weakSelf.dataList addObjectsFromArray:songs];
                [weakSelf.tableView reloadData];
            }
            weakSelf.tableView.tableHeaderView = weakSelf.headerView;
        } else {
            NSDictionary *dataDict = [object objectForKey:@"playlist"];
            NSDictionary *creator = [dataDict objectForKey:@"creator"];
            NSDictionary *dict = @{
                @"name": [dataDict objectForKey:@"name"],
                @"author": [creator objectForKey:@"nickname"],
                @"imageUrl": [dataDict objectForKey:@"coverImgUrl"],
                @"count": [dataDict objectForKey:@"trackCount"],
                @"publishTime": @([[dataDict objectForKey:@"createTime"] integerValue])
            };
            weakSelf.headerView.dataDict = dict;
            weakSelf.tableView.tableHeaderView = weakSelf.headerView;
            NSArray *tracks = [dataDict objectForKey:@"tracks"];
            if (tracks.count) {
                [weakSelf.dataList addObjectsFromArray:tracks];
                [weakSelf.tableView reloadData];
            }
        }
        
        
    } failedBlock:^(NSError *error) {
        NSLog(@"object == %@", error);
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MPAlbumListViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MPAlbumListViewCell"];
    if (!cell) {
        cell = [[MPAlbumListViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MPAlbumListViewCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.dataDict = self.dataList[indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 36;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *dataDict = self.dataList[indexPath.row];
    NSInteger songId = [[dataDict objectForKey:@"id"] integerValue];
    MPSongDetailViewController *vc = [[MPSongDetailViewController alloc] initWithSongId:songId];
    [self.navigationController pushViewController:vc animated:YES];
}

- (MPAlbumInfoHeaderView *)headerView {
    if (!_headerView) {
        _headerView = [[MPAlbumInfoHeaderView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 102)];
    }
    return _headerView;
}

@end
