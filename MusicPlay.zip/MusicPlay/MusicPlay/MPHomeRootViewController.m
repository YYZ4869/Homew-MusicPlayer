//
//  MPHomeRootViewController.m
//  MusicPlay
//
//  Created by Hanyongying on 2020/5/22.
//  Copyright © 2020 fatyou. All rights reserved.
//

#import "MPHomeRootViewController.h"
#import "MPRequestManager.h"
#import "MPHomeRecommendCell.h"
#import "MPHomeHeaderAlbumView.h"
#import "MPAlbumListViewController.h"

@interface MPHomeRootViewController ()<UICollectionViewDelegate, UICollectionViewDataSource>

@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) NSMutableArray *recommendList;
@property (nonatomic, strong) NSMutableArray *albumList;

@end

@implementation MPHomeRootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Home";
    self.recommendList = [NSMutableArray array];
    self.albumList = [NSMutableArray array];
    
    [self setupView];
    [self getAlbumData];
}

- (void)setupView {
    CGSize size = [UIScreen mainScreen].bounds.size;
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.minimumLineSpacing = 0;
    layout.minimumInteritemSpacing = 0;
    layout.itemSize = CGSizeMake((size.width - 20)/2., (size.width - 20)/2. - 10 + 62);
    
    self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(10, 0, size.width - 20, size.height - 64 - 44) collectionViewLayout:layout];
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.backgroundColor = [UIColor whiteColor];
    [self.collectionView registerClass:[MPHomeRecommendCell class] forCellWithReuseIdentifier:@"MPHomeRecommendCell"];
    [self.collectionView registerClass:[MPHomeHeaderAlbumView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"MPHomeHeaderAlbumView"];
    [self.view addSubview:self.collectionView];
}

- (void)getAlbumData {
    NSString *urlStirng = @"/album/newest";
    __weak typeof(self) weakSelf = self;
    [[MPRequestManager sharedInstance] requestWithUrl:urlStirng params:nil successBlock:^(id object) {
        NSLog(@"object == %@", object);
        NSArray *list = [object objectForKey:@"albums"];
        if (list.count) {
            [weakSelf.albumList addObjectsFromArray:list];
        }
        [weakSelf getRecomandData];
    } failedBlock:^(NSError *error) {
        NSLog(@"object == %@", error);
    }];
}

- (void)getRecomandData {
    NSString *urlStirng = @"/top/playlist";
    __weak typeof(self) weakSelf = self;
    [[MPRequestManager sharedInstance] requestWithUrl:urlStirng params:nil successBlock:^(id object) {
        NSLog(@"object == %@", object);
        NSArray *list = [object objectForKey:@"playlists"];
        [weakSelf.recommendList addObjectsFromArray:list];
        [weakSelf.collectionView reloadData];
        
    } failedBlock:^(NSError *error) {
        NSLog(@"object == %@", error);
    }];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.recommendList.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    MPHomeRecommendCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MPHomeRecommendCell" forIndexPath:indexPath];
    cell.dataDict = self.recommendList[indexPath.item];
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    MPHomeHeaderAlbumView *view = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:@"MPHomeHeaderAlbumView" forIndexPath:indexPath];
    view.dataList = self.albumList;
    [view setDidSelectedItem:^(NSInteger albumId) {
        MPAlbumListViewController *vc = [[MPAlbumListViewController alloc] initWithAlbumId:albumId isAlbum:YES];
        [self.navigationController pushViewController:vc animated:YES];
    }];
    return view;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
    //每个item也可以调成不同的大小
    CGFloat rate = 133/213.;
    CGFloat width = [UIScreen mainScreen].bounds.size.width - 40;
    CGFloat height = width * rate;
    return CGSizeMake([UIScreen mainScreen].bounds.size.width, height + 80);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *dict = self.recommendList[indexPath.item];
    NSInteger albumId = [[dict objectForKey:@"id"] integerValue];
    MPAlbumListViewController *vc = [[MPAlbumListViewController alloc] initWithAlbumId:albumId isAlbum:NO];
    [self.navigationController pushViewController:vc animated:YES];
}


@end
